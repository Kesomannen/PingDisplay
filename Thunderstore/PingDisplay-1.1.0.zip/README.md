# Ping Display

Simple ping display for Lethal Company

![image](https://github.com/Kesomannen/PingDisplay/assets/113015915/8b25a757-2fe0-4b68-ab1b-51467939458b)
